/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function main(a: number, b: number): number;
export function __wbindgen_malloc(a: number, b: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number, d: number): number;
export const __wbindgen_export_2: WebAssembly.Table;
export function wasm_bindgen__convert__closures__invoke1_mut__h0da13a1a9754d9e0(a: number, b: number, c: number): void;
export function wasm_bindgen__convert__closures__invoke0_mut__h0334e5d9c6187a42(a: number, b: number): void;
export function __wbindgen_exn_store(a: number): void;
export function __wbindgen_start(): void;
